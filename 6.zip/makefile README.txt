Il nostro makefile prevede la compilazione di main_iplib.c , creando già l'oggetto
bmp.o e l'eseguibile, quindi sostituire main_iplib.c con il file che si vuole compilare.